#pragma once

#include <iostream>

class TableClass
{
public:
	TableClass();
	~TableClass();

	int SetupTable();

};

